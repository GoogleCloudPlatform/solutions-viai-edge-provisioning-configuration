#!/usr/bin/env sh
cd /var/lib/viai/

mkdir -p ./log

. /var/lib/viai/scripts/deploy-app.sh \
  --k8s-runtime "anthos" \
  --membership "anthos-linux" \
  2>&1 | tee ./log/deploy-app.log
