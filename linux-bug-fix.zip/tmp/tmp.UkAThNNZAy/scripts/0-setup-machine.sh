#!/usr/bin/env sh

cd /var/lib/viai/
mkdir -p ./log
. /var/lib/viai/scripts/attach-cluster.sh \
          --default-project "kalschi-via-20230925-001" \
          --k8s-runtime "anthos" \
          --users "admin@kalschi.altostrat.com" \
          --membership "anthos-linux" \
          2>&1 | tee ./log/attach-cluster.log
